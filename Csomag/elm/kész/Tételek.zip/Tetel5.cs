using System;
using System.Diagnostics;

namespace hw
{
    class Tetel5
    {
        static void Main(string[] args)
        {
            #region Program leirása
            Console.WriteLine("Ez a program megnézi van-e a tömbben 13-mal osztható szám!"); /* Kiiratjuk hogy "Ez a program megnézi van-e a tömbben 13-mal osztható szám!"*/
            Console.WriteLine("(A folytatáshoz nyomj entert)");/* Kiiratjuk hogy (A folytatáshoz nyomj enter-t!)*/
            Console.ReadLine(); /* Ahhoz hogy az enter-t érzékelje, ahhoz bekell olvasnunk az adott bemenetelt*/
            Console.Clear(); /* Képernyő törlésre használjuk ezt */
            #endregion

            #region Változók létrehozása               
            int[] szam_lista = new int[10]; /* Létrekell hoznunk egy 10 elemü tömböt "szam_lista" neven, ami integer szamokat tartalmaz. */
            Random randomszam = new Random(); /* Megkell hivnunk a random osztály-t egy adott változóba, hogy random számokat tudjunk generálni. */
            #endregion


            #region Tömb feltöltése random számmal
            for (int i = 0; i < szam_lista.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szam_lista nevezetü tömb hosszáig fog menni, jelenesetbe 10-ig */
            {
                szam_lista[i] = randomszam.Next(1, 101);  /* Itt a szam_lista tömböt feltöltjük 1 és 101 közötti random számokkal. (igazságszerint ez 1-től 100-ig megy) */
            }
            #endregion

            #region Tömb elemeinek kiiratása
            for (int i = 0; i < szam_lista.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szam_lista nevezetü tömb hosszáig fog menni, jelenesetbe 10-ig */
            {
                Console.Write("{0}, ", szam_lista[i]); /* Kiiratjuk itt a tömb elemeit, ami a szam_lista tömb i.-edik elemére hivatkozva fog történni. */
            }
            Console.ReadLine();
            #endregion

            #region !Eldöntés Tétele!
            int j = 0; /* Létrehozunk egy változót "j" néven, ami integer tipusu lesz. */
            while (j < szam_lista.Length && szam_lista[j] <= 80) /* Itt előltesztelős ciklust kell használnunk, ami azt jelenti hogy addig fog lefutni a ciklus ameddig a j változó nagyobb nem lesz mint a szam_lista tömb hosszánál és ameddig a szam_lista tömb j.-edik eleme 80 nem lesz. */
            {

                {
                    j++; /* incrementáljuk itt a j változót */
                }
                if (j < szam_lista.Length)
                { /* Megnézzük hogy a j változó értéke kisebb mint a szam_lista tömb hossza, ha ez igaz akkor kikell iratnunk hogy a tömb-ben található 80 feletti szám szám, ha nem igaz, akkor kikell iratnunk hogy "A tömb-ben nincs 80 feletti szám!" */
                    Console.WriteLine("\n A tömbben van 80 feletti szám!");  /* Itt kiiratjuk hogy "A tömb-ben van 80 feletti szám!" */
                }

                else
                {
                    Console.WriteLine("\n A tömbben nincs 80 feletti szám!"); /* Itt kiiratjuk hogy "A tömb-ben nincs 80 feletti szám!" */
                }
            }
            #endregion

            Console.ReadLine();
        }
    }
}

