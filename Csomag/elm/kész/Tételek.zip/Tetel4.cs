using System;
using System.Diagnostics;

namespace hw
{
    class Tetel4
    {
        static void Main(string[] args)
        {
            #region Program leirása
            Console.WriteLine("Ez a program átnézi egy adott tömbben megtalálható-e az általunk keresett érték!"); /* Kiiratjuk hogy "Ez a program átnézi egy adott tömbben megtalálható-e az általunk keresett érték!"*/
            Console.WriteLine("(A folytatáshoz nyomj entert)");/* Kiiratjuk hogy (A folytatáshoz nyomj enter-t!)*/
            Console.ReadLine(); /* Ahhoz hogy az enter-t érzékelje, ahhoz bekell olvasnunk az adott bemenetelt*/
            Console.Clear(); /* Képernyő törlésre használjuk ezt */
            #endregion 

            #region Keresett érték bekérése
                Console.WriteLine("Add meg melyik számot szeretnéd megkeresni a tömb-ben."); /*Itt kiiratjuk hogy "Add meg melyik számot szeretnéd megkeresni a tömb-ben.")*/
                int keresett_elem = Convert.ToInt32(Console.ReadLine()); /* Bekérjük itt az értéket. */
                Console.Clear(); /* Képernyő törlésre használjuk ezt */
            #endregion
            

            #region Tömb feltöltése random számmal
            Random rnd = new Random(); /* Megkell hivnunk a random osztály-t egy adott változóba, hogy random számokat tudjunk generálni. */
            int [] szamok = new int[25];  /* Létrekell hoznunk egy 25 elemü tömböt "szamok" néven, ami csak integer számokból állhat. */                      
            for (int i = 0; i < szamok.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szamok nevezetü tömb hosszáig fog menni, jelenesetbe 25-ig */
            {
                szamok[i] = rnd.Next(1, 51);  /* Itt a szamok tömböt feltöltjük 1 és 51 közötti random számokkal. (igazságszerint ez 1-től 50-ig megy) */
            }
            #endregion
            
            #region Tömb elemeinek kiiratása
            Console.WriteLine("A tömb elemei:"); /* Kiiratjuk a "Tömb Elemei" szöveget */
            for (int i = 0; i < szamok.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szamok nevezetü tömb hosszáig fog menni, jelenesetbe 25-ig */
            {
                Console.Write("{0}, ", szamok[i]); /* Kiiratjuk itt a tömb elemeit, ami a szamok tömb i.-edik elemére hivatkozva fog történni. */
            }
            Console.ReadLine();
            #endregion

            #region Kiválasztás
            int helye = 0; /* Létrehozunk egy "helye" nevezetü változót, ami integer számokból fog állni. */
            bool van_e = false; /* Létrehozunk egy logikai változót, ami alapból false lesz */
            int j = 0; /* Létrehozunk egy "j" nevezetü változót, ami integer számokból fog állni. */
            while (j < szamok.Length && van_e == false ) /* Itt előltesztelős ciklust kell használnunk, ami azt jelenti hogy addig fog lefutni a ciklus ameddig a j változó nagyobb nem lesz mint a szamok tömb hosszánál és ha a van_e logikai változó nem true (igaz) értékkel tér vissza. */
            {
                if(szamok[j] != keresett_elem) /* Itt megkell néznünk egy elágazással, hogy a keresett_elem értékével egyezik-e a szamok tömb j.-edik eleme, ha igaz akkor itt a j változót megnöveli 1-el, ha nem akkor a van_e logikai változó értéke true lesz, és a helye változó értéke egyenlő lesz a j változó értékével. */
                {
                    j = j + 1; /* incrementáljuk itt a j változót 1-el */
                
                }
                else {
                    van_e = true; /* a van_e logikai változó átállitodik true-ra */
                    helye = j; /*a helye változó egyenlő lesz a j változó értékével. */
                }
            }
            #endregion
            #region Eredmény kiiratása
            if(van_e == true) /* Itt megkell néznünk egy elágazassal, hogy a van_e logikai változó igaz, akkor kikell iratnunk azt hogy "A szám megtalálható tömbben a {0} helyen.", ha nem igaz ez, akkor "A szám nem található meg a tömb-ben."-t kell kiiratnunk.*/
            { 
                Console.WriteLine("A szám megtalálható tömbben a {0}. helyen.", helye + 1); /* Itt kiiratjuk hogy megtalálható az adott szám a tömbben a x.-edik helyen, és a helye változót incrementáljuk 1-el. */
            } 
            else {
                Console.WriteLine("A szám nem található meg a tömb-ben.");/* Itt kiiratjuk hogy a szám nem található meg a tömb-ben. */
            }
            #endregion

            Console.ReadLine(); 
        }
    }
  }

