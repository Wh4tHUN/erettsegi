using System;
using System.Diagnostics;

namespace hw
{
    class Tetel3
    {
        static void Main(string[] args)
        {
            #region Program leirása
            Console.WriteLine("Ez a program megkeresi egy random tömbben a legkisebb és legnagyobb értéket!"); /* Kiiratjuk hogy "Ez a program megkeresi egy random tömbben a legkisebb és legnagyobb értéke."*/
            Console.WriteLine("(A folytatáshoz nyomj entert)");/* Kiiratjuk hogy (A folytatáshoz nyomj enter-t!)*/
            Console.ReadLine(); /* Ahhoz hogy az enter-t érzékelje, ahhoz bekell olvasnunk az adott bemenetelt*/
            Console.Clear(); /* Képernyő törlésre használjuk ezt */
            #endregion 

            #region A tömb létrehozása
            Random rnd = new Random(); /* Megkell hivnunk a random osztály-t egy adott változóba, hogy random számokat tudjunk generálni. */
            int [] szamok = new int[25];  /* Létrekell hoznunk egy 25 elemü tömböt "szamok" néven, ami csak integer számokból állhat. */                      
            for (int i = 0; i < szamok.Length; i++) /* Itt létrehozunk egy for ciklus-t, ami az elem i.-edik indextől fog a szamok nevezetü tömb hosszáig fog menni, jelenesetbe 25-ig */
            {
               szamok[i] = rnd.Next(1, 101); /* Itt a szamok tömböt feltölti 1 és 101 közötti random számokkal. (igazságszerint ez 1-től 100-ig megy) */
            }
            
            #endregion

            #region Tömb elemeinek kiiratása
            Console.WriteLine("A tömb elemei:"); /* Kiiratjuk a "Tömb Elemei" szöveget */
            for (int i = 0; i < szamok.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szamok nevezetü tömb hosszáig fog menni, jelenesetbe 25-ig */
            {
                Console.Write("{0}, ", szamok[i]); /* Kiiratjuk itt a tömb elemeit, ami a szamok tömb i.-edik elemére hivatkozva fog történni. */
            }
            Console.ReadLine();
            #endregion
            
            #region Minimumkeresés
            int minimum = szamok[0]; /* Itt létrehozunk egy minimum változót, ami integer tipusu lesz, és a szamok 0.-adik elemével lesz egyenlő. */
            for (int i = 0; i < szamok.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szamok nevezetü tömb hosszáig fog menni, jelenesetbe 25-ig */
            {
               if(szamok[i] < minimum) { /* Itt megnézzük egy elágazással viszonyitásképpen, hogy a szamok tömb i.-edik eleme kisebb mint a minimum, ha igaz, akkor a minimum változó egyenlő lesz a szamok tömb i.-edik elemével. */
                   minimum = szamok[i];
               }
               else { }
            } 
            Console.ReadLine();
            Console.WriteLine("A legkisebb érték a tömb-ben: {0} ", minimum); /* Kiiratjuk a szamok tömb legksiebb értékét */
            #endregion

            #region Maximumkeresés
            int maximum = szamok[0]; /* Itt létrehozunk egy maximum változót, ami integer tipusu lesz, és a szamok 0.-adik elemével lesz egyenlő. */
            for (int i = 0; i < szamok.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szamok nevezetü tömb hosszáig fog menni, jelenesetbe 25-ig */
            {
               if(szamok[i] > maximum) { /* Itt megnézzük egy elágazással viszonyitásképpen, hogy a szamok tömb i.-edik eleme nagyobb-e mint a maximum, ha igaz, akkor a maximum változó egyenlő lesz a szamok tömb i.-edik elemével. */
                   maximum = szamok[i]; 
               }
               else { }
            } 
            Console.ReadLine();
            Console.WriteLine("A legnagyobb érték a tömb-ben: {0} ", maximum); /* Kiiratjuk a szamok tömb legnagyobb értékét */
            #endregion




            Console.ReadLine(); 
        }
    }
  }

