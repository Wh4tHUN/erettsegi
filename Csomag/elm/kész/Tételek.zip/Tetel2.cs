using System;
using System.Diagnostics;

namespace hw
{
    class Tetel2
    {
        static void Main(string[] args)
        {
            #region Program leirása
            Console.WriteLine("Ez a program bemutatja hogyan mködik az összegzés és az átlagszámitás tétele."); /* Kiiratjuk hogy "Ez a program bemutatja hogyan müködik az összegzés és az átlagszámitás tétele."*/
            Console.WriteLine("(A folytatáshoz nyomj entert)");/* Kiiratjuk hogy (A folytatáshoz nyomj enter-t!)*/
            Console.ReadLine(); /* Ahhoz hogy az enter-t érzékelje, ahhoz bekell olvasnunk az adott bemenetelt*/
            Console.Clear(); /* Képernyő törlésre használjuk ezt */
            #endregion 

            #region A tömb létrehozása
            Random rnd = new Random(); /* Megkell hivnunk a random osztály-t egy adott változóba, hogy random számokat tudjunk generálni. */
            int [] randomszamok = new int[100];  /* Létrekell hoznunk egy 100 elemü tömböt "randomszamok" néven, ami csak integer számokból állhat. */                      
            for (int i = 0; i < randomszamok.Length; i++) /* Itt létrehozunk egy for ciklus-t, ami az elem i.-edik indextől fog a randomszamok nevezetü tömb hosszáig fog menni, jelenesetbe 100-ig */
            {
               randomszamok[i] = rnd.Next(1, 101); /* Itt a randomszamok tömböt feltölti 1 és 101 közötti random számokkal. (igazságszerint ez 1-től 100-ig megy) */
            }
            #endregion

            #region Összegzés tétele
            int osszeg = 0; /* Létrehozunk egy osszeg változót, ami integer tipusu lesz. */
            for (int i = 0; i < randomszamok.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a randomszamok nevezetü tömb hosszáig fog menni, jelenesetbe 100-ig */
            {
                osszeg = osszeg + randomszamok[i]; /* Megkell adnunk az "osszeg" változót, ami annyit fog csinálni hogy a randomszámok i.-edik indexét fogja összegezni, úgy hogy az osszeg változó-t összeadjük a randomszamok i.-edik elemével. */
            }
            Console.WriteLine("A random számok összege: {0}", osszeg); /* Kiiratjuk a random számok összegét. */
            #endregion 
            
            #region Átlagszámitás tétele
            /* Console.Clear(); /* Képernyő törlésre használjuk ezt 
            int osszeg = 0; /* Létrehozunk egy osszeg változót, ami integer tipusu lesz. 
            /* for (int i = 0; i < randomszamok.Length; i++) Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a randomszamok nevezetü tömb hosszáig fog menni, jelenesetbe 100-ig */
            {
               /* osszeg = osszeg + randomszamok[i]; /* Megkell adnunk az "osszeg" változót, ami annyit fog csinálni hogy a randomszámok i.-edik indexét fogja összegezni, úgy hogy az osszeg változó-t összeadjük a randomszamok i.-edik elemével. 
            } */
            Console.WriteLine("A számok átlaga: {0} ", osszeg / randomszamok.Length); /* Itt kiiratjuk a számok átlágát, úgy hogy elosszuk az osszeg változót a randomszamok tömb hosszával. */
            #endregion

            Console.ReadLine(); 
        }
    }
  }
}
