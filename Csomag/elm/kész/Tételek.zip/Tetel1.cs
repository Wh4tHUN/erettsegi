using System;

namespace hw
{
    class Tetel1
    {
        static void Main(string[] args)
        {
            #region feltöltés
            int[] tombnev = new int[10]; /* Létrekell hoznunk egy 10 elemü tömböt "tombnev" néven, ami csak integer számokból állhat. */
            int[] randomszamok = new int[10]; /* Létrekell hoznunk egy 10 elemü tömböt "randomszamok" néven, ami csak integer számokból állhat. */
            #endregion 

            #region Feltöltés értékmegadással
                                              
            for (int i = 0; i < tombnev.Length; i++) /* Itt létrehozunk egy for ciklus-t, ami az elem i.-edik indextől fog a tombnev nevezetü tömb hosszáig fog menni, jelenesetbe 10-ig */
            {
                Console.Clear(); /* Képernyő törlésre használjuk ezt */
                Console.WriteLine("Add meg a tömb {0}. indexü értékét", i); /*Itt kiiratjuk a tömb-nek az adott indexének az értékét. Az i jelöli az adott index-et. */
                tombnev[i] = Convert.ToInt32(Console.ReadLine()); /* Bekérjük itt az értéket. */
            }
            #endregion

            #region Feltöltés random számmal
            Console.Clear(); /* Képernyő törlésre használjuk ezt */
            Random rdm = new Random(); /* Itt meghivjuk a Random osztály-t egy adott változóba, ami a random számok generálására fog szolgálni.*/
            for (int i = 0; i < randomszamok.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a randomszamok nevezetü tömb hosszáig fog menni, jelenesetbe 10-ig */
            {
                randomszamok[i] = rdm.Next(1, 101);  /* Itt a randomszamok tömböt feltöltjük 1 és 101 közötti random számokkal. (igazságszerint ez 1-től 100-ig megy) */
            }
            #endregion
            #region Kiiratás
            Console.Clear(); /* Képernyő törlésre használjuk ezt */
            Console.WriteLine("Feltöltött tömb:"); /* Kiirja hogy "Feltöltött tömb" */
            for (int i = 0; i < tombnev.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a tombnev nevezetü tömb hosszáig fog menni, jelenesetbe 10-ig */
            {
                Console.Write("{0}, ", tombnev[i]); /* Kiiratjuk ezuttal a feltöltött tömb értékeit, a tombnev tömb i.-edik elemére hivatkozva. */
            }
            Console.WriteLine("\nRandom számok tömbje:"); /* Kiirja hogy Random számok tömb-je egy új sorba. */
            for (int i = 0; i < randomszamok.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a randomszamok nevezetü tömb hosszáig fog menni, jelenesetbe 10-ig */
            {
                Console.Write("{0}, ", randomszamok[i]);/*  Kiiratjuk ezuttal a random számokból álló tömb értékeit, a randomszamok tömb i.-edik elemére hivatkozva. */
            }
            #endregion

            Console.ReadLine();
        }
    }
}
