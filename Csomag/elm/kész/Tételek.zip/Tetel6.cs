﻿using System;
using System.Diagnostics;

namespace hw
{
    class Tetel6
    {
        static void Main(string[] args)
        {
            #region Program leirása
            Console.WriteLine("Ez a program megnézi van-e a tömbben 13-mal osztható szám!"); /* Kiiratjuk hogy "Ez a program megnézi van-e a tömbben 13-mal osztható szám!"*/
            Console.WriteLine("(A folytatáshoz nyomj entert)");/* Kiiratjuk hogy (A folytatáshoz nyomj enter-t!)*/
            Console.ReadLine(); /* Ahhoz hogy az enter-t érzékelje, ahhoz bekell olvasnunk az adott bemenetelt*/
            Console.Clear(); /* Képernyő törlésre használjuk ezt */
            #endregion

            #region Változók létrehozása               
            int[] szam_lista = new int[20]; /* Létrehozunk egy 20 elemü tömböt "szam_lista" néven, ami integer számokat tartalmaz. */ 
            Random randomszam = new Random(); /* Megkell hivnunk a random osztály-t egy adott változóba, hogy random számokat tudjunk generálni. */
            int darab = 0; /* Itt létrehozunk egy "darab" nevezetü változót, ami integer tipusu lesz. */
            #endregion


            #region Tömb feltöltése random számmal
            for (int i = 0; i < szam_lista.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szam_lista nevezetü tömb hosszáig fog menni, jelenesetbe 20-ig */
            {
                szam_lista[i] = randomszam.Next(1, 100);  /* Itt a szam_lista tömböt feltöltjük 1 és 100 közötti random számokkal. (igazságszerint ez 1-től 99-ig megy) */
            }
            #endregion

            #region Tömb elemeinek kiiratása
            for (int i = 0; i < szam_lista.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szam_lista nevezetü tömb hosszáig fog menni, jelenesetbe 20-ig */
            {
                Console.Write("{0}, ", szam_lista[i]); /* Kiiratjuk itt a tömb elemeit, ami a szam_lista tömb i.-edik elemére hivatkozva fog történni. */
            }
            Console.ReadLine();
            #endregion

            #region Kiválogatás Tétele
            Console.WriteLine("\n\nA páros számok a tömbben:"); /*Itt kiiratjuk hogy "A páros számok a tömb-ben:" */
            
            for (int i = 0; i < szam_lista.Length; i++) /* Itt létrehozunk egy for ciklus-t,ami az i.-edik elemtől fog a szam_lista nevezetü tömb hosszáig fog menni, jelenesetbe 20-ig */
            {
                if(szam_lista[i] % 2 == 0) /* Itt egy elágazassal megnézzük, hogy a szam_lista i.-edik eleme oszható-e 2-vel, ha osztható, akkor kiirja a szam_lista tömb i.-edik elemét, és incrementlája a darab változót, ha nem, akkor semmit nem ir ki. */
                {
                    Console.Write("{0}, ", szam_lista[i]);
                    darab++;
                }
                else
                {

                }
            }
            Console.WriteLine("\nÖsszesen {0} darab páros szám volt a tömb-ben.", darab); /* Itt kiiratjuk hogy mennyi darab páros volt a tömb-ben. */
            #endregion
            Console.ReadLine();
        }
    }
}

